// 认证预检硬闸门的前端协同：任务创建收到 409 AUTH_PREFLIGHT_REQUIRED 时，
// 唤起集中认证面板，认证齐备后自动重发原始请求（服务端会重新探测登录态）。
export type AuthPreflightPlatform = { source: string; label: string; state: string; ready: boolean; message?: string };

export const AUTH_PREFLIGHT_EVENT = 'workbench:auth-preflight';
export const AUTH_PREFLIGHT_READY_EVENT = 'workbench:auth-preflight-ready';
export const AUTH_PREFLIGHT_CANCEL_EVENT = 'workbench:auth-preflight-cancel';

type PreflightDetail = { code?: string; message?: string; platforms?: AuthPreflightPlatform[] };

function waitForPreflight(message?: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const cleanup = () => {
      window.removeEventListener(AUTH_PREFLIGHT_READY_EVENT, onReady);
      window.removeEventListener(AUTH_PREFLIGHT_CANCEL_EVENT, onCancel);
      clearTimeout(timer);
    };
    const onReady = () => { cleanup(); resolve(); };
    const onCancel = () => {
      cleanup();
      reject(new Error(message || '认证未完成，本次任务未创建；请完成平台认证后重新发起'));
    };
    const timer = setTimeout(onCancel, 10 * 60 * 1000);
    window.addEventListener(AUTH_PREFLIGHT_READY_EVENT, onReady);
    window.addEventListener(AUTH_PREFLIGHT_CANCEL_EVENT, onCancel);
  });
}

export async function fetchWithPreflight(url: string, init: RequestInit | undefined,
                                          doFetch: (url: string, init?: RequestInit) => Promise<Response>): Promise<Response> {
  const response = await doFetch(url, init);
  if (response.status !== 409) return response;
  let detail: PreflightDetail;
  try {
    detail = await response.clone().json();
  } catch {
    return response;
  }
  if (detail?.code !== 'AUTH_PREFLIGHT_REQUIRED') return response;
  window.dispatchEvent(new CustomEvent<AuthPreflightPlatform[]>(AUTH_PREFLIGHT_EVENT, { detail: detail.platforms || [] }));
  await waitForPreflight(detail.message);
  return doFetch(url, init);
}

import test from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {SourceLoginPanel,type DesktopAuth} from '../src/components/SourceLoginPanel';

const fields=[{id:'phone',type:'tel',role:'phone',label:'手机号码',filled:false},{id:'code',type:'text',role:'sms_code',label:'短信验证码',filled:false}];
const controls=[{id:'send',kind:'sms',label:'获取验证码'},{id:'login',kind:'submit',label:'登录'}];
function render(desktop:DesktopAuth,source='xiaoxiang',extraFields:any[]=[]){
  return renderToStaticMarkup(React.createElement(SourceLoginPanel,{source,sessionId:'synthetic',desktop:{fields:[...fields,...extraFields],controls,...desktop},apiFetch:async()=>{throw new Error('Rendering must not send any request');}}));
}
test('normal SMS form has no official verification panel or external browser',()=>{
  const html=render({});assert.match(html,/获取验证码/);assert.match(html,/短信验证码/);
  assert.doesNotMatch(html,/aria-label="官方安全验证"|<iframe|window\.open/);
});
test('actual challenge conditionally displays manual verification and disables ordinary SMS action',()=>{
  const html=render({has_challenge:true,challenge_id:'widget',challenge_version:'image'});
  assert.match(html,/aria-label="官方安全验证"/);assert.match(html,/手动点击或拖动/);
  assert.match(html,/<button[^>]*disabled=""[^>]*>获取验证码/);
  assert.doesNotMatch(render({has_challenge:true,challenge_id:'widget'}),/aria-label="官方安全验证"/);
  assert.doesNotMatch(render({has_challenge:true,challenge_id:'widget',challenge_version:'image'},'lanorange'),/aria-label="官方安全验证"/);
});
test('official detail is escaped text and never rendered as an official HTML page',()=>{
  const html=render({official_feedback:'官方未接受此次操作',official_feedback_detail:'环境异常 <script>synthetic</script>'});
  assert.match(html,/环境异常 &lt;script&gt;/);assert.doesNotMatch(html,/<script>|<iframe/);
});
test('consent checkbox and dynamic voice code are handled inside the panel',()=>{
  const consent={id:'agree',type:'checkbox',role:'consent',label:'我已阅读并同意《用户协议》《隐私政策》',filled:true,auto:true};
  const voice={id:'voice',type:'text',role:'voice_code',label:'请输入语音电话里的验证码',filled:false};
  const html=render({},'xiaoxiang',[consent,voice]);
  assert.match(html,/wb-auth-consent/);assert.match(html,/我已阅读并同意/);
  assert.match(html,/用户协议已由系统自动勾选/);
  assert.match(html,/语音验证码/);assert.match(html,/动态码/);
  assert.doesNotMatch(html,/固定码|value="908405"|<iframe|window\.open/);
});
test('voice stage is a neutral notice, not a security-verification error',()=>{
  const html=render({official_feedback:'官方已进入语音二次验证；语音验证码为动态码，请接听语音电话后填入',official_feedback_kind:'voice_required'});
  assert.match(html,/语音二次验证/);
  assert.match(html,/class="wb-muted"[^>]*>官方已进入语音二次验证/);
  assert.doesNotMatch(html,/wb-error/);
  assert.doesNotMatch(html,/<iframe/);
});
test('lighthouse stage shows the Meituan App QR instead of the SMS form',()=>{
  const html=render({has_qr:true,qr_stage:'lighthouse',qr_state:'visible',qr_version:'v1'});
  assert.match(html,/美团App/);assert.match(html,/正在准备美团登录二维码/);
  assert.doesNotMatch(html,/知了看板|获取验证码/);
});
test('board stage keeps the Zhiliao scan guidance after the lighthouse login',()=>{
  const html=render({has_qr:true,qr_stage:'board',qr_state:'visible',qr_version:'v1'});
  assert.match(html,/知了看板/);assert.match(html,/灯塔登录已完成/);
});
test('reused lighthouse session tells the user the Meituan scan was skipped',()=>{
  const html=render({has_qr:true,qr_stage:'board',qr_state:'visible',qr_version:'v1',lighthouse_reused:true,window_visible:false});
  assert.match(html,/灯塔会话仍有效，已跳过美团扫码/);
  assert.match(html,/请用大象扫码/);
  assert.doesNotMatch(html,/请用美团App扫描面板中的二维码/);
});
test('reused board session needs only the Meituan scan',()=>{
  const html=render({has_qr:true,qr_stage:'lighthouse',qr_state:'visible',qr_version:'v1',board_reused:true,window_visible:false});
  assert.match(html,/本机保留知了看板登录态/);
  assert.match(html,/只需用美团App扫描面板中的二维码/);
  assert.match(html,/无需再扫大象/);
  assert.doesNotMatch(html,/请用大象扫描面板中的二维码/);
});
test('expired board session falls back to the 大象 scan instead of claiming reuse',()=>{
  const html=render({has_qr:true,qr_stage:'board',qr_state:'visible',qr_version:'v1',board_reused:true});
  assert.match(html,/本机保留的看板登录态已失效；请用大象扫码/);
  assert.doesNotMatch(html,/灯塔登录已完成；请用大象或美团扫码/);
});

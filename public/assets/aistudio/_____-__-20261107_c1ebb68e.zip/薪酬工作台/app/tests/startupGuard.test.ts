import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import net from 'node:net';
import type { AddressInfo } from 'node:net';
import test from 'node:test';
import { acquireStartupLock, assertPortAvailable } from '../server/startupGuard.ts';

test('a duplicate startup refuses without terminating or changing the first lock', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'payroll-startup-test-'));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  const filename = path.join(directory, 'server.lock');
  const release = acquireStartupLock(filename);
  const original = fs.readFileSync(filename, 'utf8');
  assert.throws(() => acquireStartupLock(filename), /系统已经运行/);
  assert.equal(fs.readFileSync(filename, 'utf8'), original);
  release();
  assert.equal(fs.existsSync(filename), false);
});

test('stale lock is reclaimed only after its recorded process is absent', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'payroll-startup-test-'));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  const filename = path.join(directory, 'server.lock');
  fs.writeFileSync(filename, JSON.stringify({ pid: 1234567, token: 'stale-synthetic-owner' }));
  t.mock.method(process, 'kill', () => { throw Object.assign(new Error('gone'), { code: 'ESRCH' }); });
  const release = acquireStartupLock(filename);
  assert.equal(JSON.parse(fs.readFileSync(filename, 'utf8')).pid, process.pid);
  release();
  assert.equal(fs.existsSync(filename), false);
});

test('malformed lock is preserved for explicit inspection rather than overwritten', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'payroll-startup-test-'));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  const filename = path.join(directory, 'server.lock');
  fs.writeFileSync(filename, 'not-json');
  assert.throws(() => acquireStartupLock(filename), /启动锁无效/);
  assert.equal(fs.readFileSync(filename, 'utf8'), 'not-json');
});

test('occupied backend port fails preflight and leaves the existing listener alive', async t => {
  const listener = net.createServer();
  await new Promise<void>(resolve => listener.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise<void>(resolve => listener.close(() => resolve())));
  const port = (listener.address() as AddressInfo).port;
  await assert.rejects(assertPortAvailable(port, '127.0.0.1'), /已被占用/);
  assert.equal(listener.listening, true);
});

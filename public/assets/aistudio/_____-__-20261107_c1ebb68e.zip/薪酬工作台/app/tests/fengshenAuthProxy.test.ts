import assert from 'node:assert/strict';
import http, { type Server } from 'node:http';
import type { AddressInfo } from 'node:net';
import test from 'node:test';
import express from 'express';
import { createProxyMiddleware } from 'http-proxy-middleware';
import { createFengshenAuthProxy, isFengshenAuthProxyPath } from '../server/fengshenAuthProxy.ts';

const AUTH = '/api/parttime/fengshen/auth';

test('auth filter matches canonical and once-encoded paths without interpreting query values', () => {
  for (const path of [AUTH, AUTH + '/status', AUTH + '/start?next=%FF',
    '/api/parttime/fengshen/%61uth/start', '/api/parttime/fengshen/auth%2Fstart',
    '/api%2Fparttime%2Ffengshen%2Fauth%2Fstart', '/%61pi/parttime/fengshen/auth/start']) {
    assert.equal(isFengshenAuthProxyPath(path), true, path);
  }
  for (const path of ['/api/ordinary', '/api/parttime/fengshen/authentic/start',
    '/api/ordinary?next=' + AUTH + '/start', '/api/ordinary?bad=%ZZ',
    '/api/parttime/fengshen/%2561uth/start']) {
    assert.equal(isFengshenAuthProxyPath(path), false, path);
  }
});

test('malformed encodings fail closed by retaining the client Host', () => {
  for (const path of ['/api/parttime/fengshen/%ZZauth/start', '/api/%', '/api/%FF']) {
    assert.equal(isFengshenAuthProxyPath(path), true, path);
  }
});

async function listen(server: Server) {
  await new Promise<void>((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  return (server.address() as AddressInfo).port;
}

async function close(server: Server) {
  server.closeAllConnections();
  await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
}

interface Received {
  path: string;
  method: string;
  host: string;
  origin?: string;
  workspace?: string;
  contentType?: string;
  forwardedHeaders: string[];
  body: string;
}

test('real Express proxy preserves auth Host, Origin, and JSON body across encoded paths', async t => {
  const backend = http.createServer(async (req, res) => {
    let body = '';
    for await (const chunk of req) body += chunk.toString();
    const received: Received = {
      path: req.url!, method: req.method!, host: req.headers.host!, origin: req.headers.origin,
      workspace: req.headers['x-workspace-id'] as string | undefined,
      contentType: req.headers['content-type'], body,
      forwardedHeaders: Object.keys(req.headers).filter(name => name === 'forwarded' || name.startsWith('x-forwarded-')),
    };
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(received));
  });
  const backendPort = await listen(backend);
  t.after(() => close(backend));
  const app = express();
  const options = { target: `http://127.0.0.1:${backendPort}`, changeOrigin: true };
  app.use(createFengshenAuthProxy(options));
  app.use(createProxyMiddleware({ pathFilter: '/api', ...options }));
  app.use((_req, res) => res.status(404).end());
  const frontend = http.createServer(app);
  const frontendPort = await listen(frontend);
  t.after(() => close(frontend));

  function request(path: string, host: string, origin?: string) {
    const body = JSON.stringify({ challenge_id: 'synthetic-challenge', code: 'synthetic-code' });
    return new Promise<Received>((resolve, reject) => {
      const outgoing = http.request({
        hostname: '127.0.0.1', port: frontendPort, path, method: 'POST',
        headers: { Host: host, ...(origin ? { Origin: origin } : {}),
          'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body), 'x-workspace-id': 'synthetic-workspace',
          Forwarded: 'for=203.0.113.1;host=external.invalid;proto=https',
          'X-Forwarded-For': '203.0.113.1', 'X-Forwarded-Host': 'external.invalid',
          'X-Forwarded-Proto': 'https', 'X-Forwarded-Port': '443', 'X-Forwarded-Prefix': '/synthetic' },
      }, response => {
        let result = '';
        response.setEncoding('utf8');
        response.on('data', chunk => { result += chunk; });
        response.on('end', () => {
          try { resolve(JSON.parse(result)); } catch (error) { reject(error); }
        });
      });
      outgoing.once('error', reject);
      outgoing.end(body);
    });
  }

  for (const path of [AUTH + '/verify', '/api/parttime/fengshen/%61uth/verify',
    '/api/parttime/fengshen/auth%2Fverify', '/api%2Fparttime%2Ffengshen%2Fauth%2Fverify',
    AUTH + '/verify?redirect=%2Fapi%2Fother']) {
    const result = await request(path, '192.168.1.2:3000', 'http://192.168.1.2:3000');
    assert.equal(result.host, '192.168.1.2:3000', path);
    assert.equal(result.origin, 'http://192.168.1.2:3000', path);
    assert.equal(result.path, path, path);
    assert.equal(result.method, 'POST');
    assert.equal(result.workspace, 'synthetic-workspace');
    assert.equal(result.contentType, 'application/json');
    assert.deepEqual(result.forwardedHeaders, [], path);
    assert.deepEqual(JSON.parse(result.body), { challenge_id: 'synthetic-challenge', code: 'synthetic-code' });
  }
  for (const host of ['localhost:3000', '127.0.0.1:3000', '[fd00::2]:3000']) {
    const result = await request(AUTH + '/start', host, 'http://' + host);
    assert.equal(result.host, host);
    assert.equal(result.origin, 'http://' + host);
    assert.deepEqual(result.forwardedHeaders, []);
  }
  for (const path of ['/api/parttime/fengshen/%61uth/start', '/api/parttime/fengshen/auth%2Fstart', '/api/%ZZ']) {
    const result = await request(path, '192.168.1.2:3000');
    assert.equal(result.host, '192.168.1.2:3000', path);
    assert.equal(result.origin, undefined);
    assert.deepEqual(result.forwardedHeaders, [], path);
  }
  const foreign = await request(AUTH + '/start', '192.168.1.2:3000', 'https://external.invalid');
  assert.equal(foreign.origin, 'https://external.invalid');
  assert.equal(foreign.host, '192.168.1.2:3000');
  assert.deepEqual(foreign.forwardedHeaders, []);
  for (const path of ['/api/ordinary', '/api/ordinary?next=' + AUTH + '/start', '/api/parttime/fengshen/authentic/start']) {
    const ordinary = await request(path, '192.168.1.2:3000', 'http://192.168.1.2:3000');
    assert.equal(ordinary.host, `127.0.0.1:${backendPort}`, path);
    assert.equal(ordinary.origin, 'http://192.168.1.2:3000', path);
    assert.equal(ordinary.forwardedHeaders.length, 6, path);
  }
});

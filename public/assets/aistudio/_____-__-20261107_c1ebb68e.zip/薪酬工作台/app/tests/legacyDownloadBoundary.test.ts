import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import test, { type TestContext } from 'node:test';
import { createLegacyBoundary } from '../server/legacyDownloadBoundary.ts';

function fixture(t: TestContext) {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'download-boundary-test-'));
  assert.ok(path.resolve(directory).startsWith(path.resolve(os.tmpdir()) + path.sep));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  const project = path.join(directory, 'project');
  const historic = path.join(directory, 'old-archive');
  const registry = path.join(project, 'backend', '.local_downloads', 'protected_roots.json');
  fs.mkdirSync(path.dirname(registry), { recursive: true });
  fs.writeFileSync(registry, JSON.stringify({ roots: [historic] }));
  return { project, historic, registry, directory, boundary: createLegacyBoundary(project) };
}

test('legacy API blocks download archives, private account state and historical external roots', t => {
  const { project, historic, boundary } = fixture(t);
  for (const filename of [path.join(project, 'backend/.local_downloads/accounts.sqlite3'),
    path.join(project, 'backend/.local_auth/fengshen.dpapi'), path.join(project, 'outputs/fengshen_downloads/2026-10/a.csv'),
    path.join(historic, 'city/a.csv')]) assert.equal(boundary.allowedPath(filename), false, filename);
  assert.equal(boundary.allowedPath(path.join(historic + '-sibling', 'a.csv')), true);
});

test('recursive archive/delete of a parent is refused while nonrecursive business listings remain usable', t => {
  const { project, boundary } = fixture(t);
  const outputs = path.join(project, 'outputs');
  assert.equal(boundary.allowedPath(outputs), true);
  assert.equal(boundary.allowedPath(outputs, { recursive: true }), false);
  assert.equal(boundary.bodyAllowed({ path: outputs }, '/api/files'), true);
  assert.equal(boundary.bodyAllowed({ path: outputs, action: 'delete' }, '/api/action_file'), false);
  assert.equal(boundary.bodyAllowed({ basePath: outputs, sourcePath: path.join(project, 'uploads/a') }, '/api/run'), true);
});

test('legacy writes cannot replace project code and nested task paths obey the same boundary', t => {
  const { project, boundary } = fixture(t);
  assert.equal(boundary.allowedPath(path.join(project, 'backend/main.py'), { write: true }), false);
  assert.equal(boundary.allowedPath(path.join(project, 'dist/server.cjs'), { write: true }), false);
  assert.equal(boundary.allowedPath(path.join(project, 'uploads/a/template.xlsx'), { write: true }), true);
  assert.equal(boundary.bodyAllowed({ taskQueue: [{ sourcePath: path.join(project, 'backend/.local_downloads') }] }, '/api/run'), false);
});

test('missing or corrupt registry fails closed and newly registered roots are picked up without restart', t => {
  const { project, historic, registry, boundary } = fixture(t);
  const next = historic + '-next';
  assert.equal(boundary.allowedPath(next), true);
  fs.writeFileSync(registry, JSON.stringify({ roots: [historic, next] }));
  assert.equal(boundary.allowedPath(next), false);
  fs.writeFileSync(registry, 'broken');
  assert.equal(boundary.allowedPath(path.join(project, 'uploads/a')), false);
  fs.unlinkSync(registry);
  assert.equal(boundary.allowedPath(path.join(project, 'uploads/a')), false);
});

test('existing directory junctions cannot disguise account state as an ordinary upload directory', t => {
  const { project, boundary } = fixture(t);
  const alias = path.join(project, 'uploads', 'alias');
  fs.mkdirSync(path.dirname(alias), { recursive: true });
  fs.symlinkSync(path.join(project, 'backend/.local_downloads'), alias, 'junction');
  assert.equal(boundary.allowedPath(path.join(alias, 'accounts.sqlite3')), false);
  assert.equal(boundary.allowedTree(path.dirname(alias)), false);
  fs.unlinkSync(alias);
  assert.equal(boundary.allowedTree(path.dirname(alias)), true);
});

test('forged reserved owner and development filesystem paths are refused before legacy handlers', t => {
  const { project, boundary } = fixture(t);
  for (const value of ['account_' + 'a'.repeat(32), '%61ccount_' + 'a'.repeat(32), 'ACCOUNT_' + 'a'.repeat(32)]) {
    let status = 0;
    let nextCalled = false;
    const req: any = { path: '/api/upload/config', query: {}, header: () => value };
    const res: any = { status(code: number) { status = code; return this; }, json() { return this; } };
    boundary.guardRequest(req, res, () => { nextCalled = true; });
    assert.equal(status, 403);
    assert.equal(nextCalled, false);
  }
  for (const route of ['/@fs/' + path.join(project, 'backend/.local_downloads/accounts.sqlite3'),
    '/backend/.local_downloads/accounts.sqlite3']) {
    let status = 0;
    const res: any = { status(code: number) { status = code; return this; }, json() { return this; } };
    boundary.guardRequest({ path: route, query: {}, header: () => undefined } as any, res,
      () => assert.fail('private state must not reach static file serving'));
    assert.equal(status, 403);
  }
});

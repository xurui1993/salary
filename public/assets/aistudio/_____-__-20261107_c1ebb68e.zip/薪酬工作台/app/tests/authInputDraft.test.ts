import test from 'node:test';
import assert from 'node:assert/strict';
import {reconcileAuthDraft,type AuthDraftScope} from '../src/lib/authInputDraft';
const fields=[{id:'account',type:'text',role:'username'},{id:'password',type:'password',role:'password'},{id:'math',type:'text',role:'math'}];
const scope:AuthDraftScope={source:'baize',sessionId:'test-session',fields,captchaId:'captcha-1'};
test('polling and control revisions retain same-field password drafts without mutating input',()=>{
 const values={account:'synthetic-account',password:'synthetic-only',math:'1'};
 assert.deepEqual(reconcileAuthDraft(values,scope,{...scope,fields:fields.map(field=>({...field}))}),values);
 assert.equal(values.password,'synthetic-only');
});
test('captcha refresh clears only the expired answer and retains password',()=>{
 const values={account:'synthetic-account',password:'synthetic-only',math:'1'};
 assert.deepEqual(reconcileAuthDraft(values,scope,{...scope,captchaId:'captcha-2'}),{account:'synthetic-account',password:'synthetic-only'});
});
test('new session, source, or password field never inherits a previous password',()=>{
 const values={account:'synthetic-account',password:'synthetic-only',math:'1'};
 assert.deepEqual(reconcileAuthDraft(values,scope,{...scope,sessionId:'new-session'}),{});
 assert.deepEqual(reconcileAuthDraft(values,scope,{...scope,source:'xiaoxiang'}),{});
 assert.equal(reconcileAuthDraft(values,scope,{...scope,fields:fields.map(f=>f.id==='password'?{...f,id:'new-password'}:f)}).password,undefined);
 assert.equal(reconcileAuthDraft(values,scope,{...scope,fields:fields.map(f=>f.id==='password'?{...f,type:'text'}:f)}).password,undefined);
 assert.equal(reconcileAuthDraft(values,scope,{...scope,fields:[]}).password,undefined);
});

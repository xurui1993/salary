import assert from 'node:assert/strict';
import test from 'node:test';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { ReportBuilder } from '../src/components/ReportBuilder';
import { monthBounds, reportRange, type ReportDefinition } from '../src/lib/reportBuilder';
import { isGenerator, registerGeneratorIds } from '../src/lib/taskCatalog';

const monthly:ReportDefinition={id:'payment_binding',label:'骑手支付绑定',scope:'city_month',description:'生成支付绑定表',sources:['来源'],station_rule:'separation'};
test('report periods preserve whole months, leap years and cross-year bounds',()=>{
  assert.deepEqual(reportRange(monthly,'2024-02-12','2024-02-20','2026-10-31'),{start:'2024-02-01',end:'2024-02-29',months:1});
  assert.deepEqual(reportRange(monthly,'2025-12-15','2026-01-01','2026-10-31'),{start:'2025-12-01',end:'2026-01-31',months:2});
  assert.deepEqual(monthBounds('2026-02'),{start:'2026-02-01',end:'2026-02-28'});
});
test('current month requests never send future dates and invalid ranges cannot submit',()=>{
  assert.deepEqual(reportRange(monthly,'2026-10-01','2026-10-31','2026-10-20'),{start:'2026-10-01',end:'2026-10-20',months:1});
  for(const [start,end] of [['','2026-10-01'],['2026-02-30','2026-03-01'],['2026-10-01','2026-09-01'],['2026-11-01','2026-11-30']])assert.equal(reportRange(monthly,start,end,'2026-10-20'),null);
  assert.equal(reportRange({...monthly,scope:'city_range'},'2026-10-01','2026-10-21','2026-10-20'),null);
});
test('monthly report visibly exposes editable city/month controls instead of a summary only',()=>{
  const html=renderToStaticMarkup(React.createElement(ReportBuilder,props(monthly)));
  assert.match(html,/aria-labelledby="report-city-label"/);
  assert.match(html,/aria-label="报表开始月份"/);
  assert.match(html,/aria-label="报表结束月份"/);
  assert.match(html,/aria-label="报表站点范围"/);
  assert.doesNotMatch(html,/<details[^>]*open/);
});
test('global report displays real fixed scope without misleading city or date selectors',()=>{
  const global:ReportDefinition={...monthly,id:'abnormal_riders',scope:'all',station_rule:'none'};
  const html=renderToStaticMarkup(React.createElement(ReportBuilder,props(global)));
  assert.match(html,/全部城市/);assert.match(html,/不按日期筛选/);
  assert.doesNotMatch(html,/aria-label="报表开始月份"|aria-labelledby="report-city-label"|aria-label="报表站点范围"/);
  assert.deepEqual(reportRange(global,'invalid','invalid','2026-10-31'),{start:'',end:'',months:0});
});
test('server-registered reports can be classified without modifying page code',()=>{
  registerGeneratorIds(['future-business-report']);
  assert.equal(isGenerator('future-business-report'),true);
  const future={...monthly,id:'future-business-report',label:'新业务报表'};
  assert.match(renderToStaticMarkup(React.createElement(ReportBuilder,props(future))),/新业务报表/);
});
function props(report:ReportDefinition){
  const noop=()=>{};
  return {reports:[report],selectedId:report.id,onSelect:noop,cities:[{id:'1',name:'上海'}],selectedCities:[],onCities:noop,start:'2026-09-01',end:'2026-09-30',today:'2026-10-31',onStart:noop,onEnd:noop,includeSeparation:false,onSeparation:noop,locked:false,creating:false,disabled:true,submitLabel:'生成报表',onSubmit:noop,uncertain:false,duplicate:false,recollect:false,onRecollect:noop,refreshing:false,onRefreshCities:noop};
}

import test from 'node:test';
import assert from 'node:assert/strict';
import { readDownloadResponse, downloadOutput } from '../src/lib/outputDownload';
import { recoverable, recoverySummary } from '../src/lib/downloadCenterLogic';

test('HTML and JSON error pages cannot be saved as XLSX files', async () => {
 for (const type of ['text/html','application/json']) await assert.rejects(readDownloadResponse(new Response('not a file',{headers:{'content-type':type}}),'result.xlsx'), /提示页面/);
});
test('truncated HTTP bodies and invalid archive signatures are rejected', async () => {
 await assert.rejects(readDownloadResponse(new Response('abc',{headers:{'content-length':'12'}}),'result.csv'), /不完整/);
 await assert.rejects(readDownloadResponse(new Response('wrong bytes'),'result.zip'), /不是有效/);
});
test('ZIP/XLSX signatures and legitimate JSON exports are accepted', async () => {
 const bytes=new Uint8Array([80,75,3,4,10]);
 assert.equal((await readDownloadResponse(new Response(bytes),'中文结果.xlsx')).size,5);
 assert.equal((await readDownloadResponse(new Response('{}',{headers:{'content-type':'application/json'}}),'扣款.json')).size,2);
});
test('unknown or submitted exports never offer unsubmitted-item retries', () => {
 for (const submission_state of ['unknown','submitted']) assert.equal(recoverable({status:'error',submission_state,recovery:{mode:'retry_unsubmitted',reason:'contradictory'}}),false);
 assert.equal(recoverable({status:'error',submission_state:'submitted',recovery:{mode:'resume_existing',reason:'receipt verified'}}),true);
});
test('recovery summary separates retained successes, existing materials, unsubmitted and blocked items', () => {
 assert.deepEqual(recoverySummary([{status:'success'}, {status:'error',recovery:{mode:'resume_existing',reason:''}}, {status:'interrupted',submission_state:'not_submitted',recovery:{mode:'retry_unsubmitted',reason:''}}, {status:'error',submission_state:'unknown',recovery:{mode:'blocked',reason:''}}]),{retained:1,continuing:1,unsubmitted:1,blocked:1});
});

test('download network errors have an actionable message and never resubmit a task', async () => {
 let calls=0;
 await assert.rejects(downloadOutput('/local-file','scope','file.zip',async()=>{calls++;throw new TypeError('network failure')}),/连接中断/);
 assert.equal(calls,1);
});

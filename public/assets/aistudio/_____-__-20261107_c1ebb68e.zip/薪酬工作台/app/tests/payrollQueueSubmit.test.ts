import {test} from 'node:test';
import assert from 'node:assert/strict';
import {prepareQueueSubmission,pendingQueueSubmission,sendQueueSubmission,queueUploadFiles} from '../src/lib/payrollQueueSubmit';
function storage(){const data=new Map<string,string>();return {getItem:(k:string)=>data.get(k)||null,setItem:(k:string,v:string)=>{data.set(k,v);},removeItem:(k:string)=>{data.delete(k);}};}
test('same-name automatic templates get separate archive paths while manual source grouping is preserved',async()=>{
 const a=new File(['first'],'template.xlsx'),b=new File(['second'],'template.xlsx');
 const files=[{file:a,relativePath:a.name},{file:b,relativePath:b.name}];
 const selected=queueUploadFiles(files,'fengshen');assert.equal(new Set(selected.map(e=>e.relativePath)).size,2);
 assert.equal(selected[0].file,a);assert.equal(selected[1].file,b);assert.equal(await selected[0].file.text(),'first');assert.equal(await selected[1].file.text(),'second');
 assert.equal(queueUploadFiles(files,'manual'),files);assert.equal(files[0].relativePath,'template.xlsx');
});
test('an uncertain upload retains its frozen submission and resumes with the identical request id',async()=>{
 const store=storage(),payload={source_path:'retained-upload',mode:'fengshen' as const,config:{payrollExcludeSeparation:true}};
 const first=prepareQueueSubmission('shared',payload,store);payload.config.payrollExcludeSeparation=false;
 await assert.rejects(sendQueueSubmission('shared',first,async()=>{throw Error('network');},store),/尚未确认/);
 assert.throws(()=>prepareQueueSubmission('shared',payload,store),/上一批/);
 const recovered=pendingQueueSubmission('shared',store)!;assert.equal(recovered.request_id,first.request_id);assert.equal(recovered.config.payrollExcludeSeparation,true);
 await sendQueueSubmission('shared',recovered,async(_url,init)=>{assert.equal(JSON.parse(String(init?.body)).request_id,first.request_id);return new Response(JSON.stringify({tasks:[{id:'existing'}]}));},store);
 assert.equal(pendingQueueSubmission('shared',store),null);assert.equal(pendingQueueSubmission('different-workspace',store),null);
});
test('a definite rejection clears pending submission and preserves its actionable reason',async()=>{
 const store=storage(),attempt=prepareQueueSubmission('shared',{source_path:'upload',mode:'manual',config:{}},store);
 await assert.rejects(sendQueueSubmission('shared',attempt,async()=>new Response(JSON.stringify({detail:'模板目录不可访问'}),{status:400}),store),/模板目录不可访问/);
 assert.equal(pendingQueueSubmission('shared',store),null);
});

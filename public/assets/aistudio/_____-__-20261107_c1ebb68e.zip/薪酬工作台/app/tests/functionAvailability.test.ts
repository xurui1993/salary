import {test} from 'node:test';
import assert from 'node:assert/strict';
import {functionAvailability} from '../src/lib/functionAvailability';
import {stationFilterChoices} from '../src/lib/stationFilterChoices';

test('station success does not claim board authentication or all data permissions',()=>{
  const text=functionAvailability('xiaoxiang',{saved:true,state:'saved',capabilities:{stations:{verified:true}},stages:{board:'pending'}});
  assert.match(text,/站点目录已验证/);assert.match(text,/日分析权限待验证/);
  assert.match(functionAvailability('xiaoxiang',{saved:true,offline:true}),/暂不可读/);
  assert.match(functionAvailability('fengshen',{saved:true,state:'saved'}),/尚未验证/);
});
test('same-name station IDs remain visible and ambiguous name filters require a city',()=>{
  const rows=[{id:'0001',name:'同名站',city:'甲'},{id:'90071992547409931',name:'同名站',city:'乙'}];
  const all=stationFilterChoices(rows,'');assert.equal(all.length,2);assert.ok(all.every(s=>s.ambiguous));
  const city=stationFilterChoices(rows,'乙');assert.equal(city[0].id,'90071992547409931');assert.equal(city[0].ambiguous,false);
});

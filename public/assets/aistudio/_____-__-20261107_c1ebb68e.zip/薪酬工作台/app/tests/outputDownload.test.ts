import assert from 'node:assert/strict';
import test from 'node:test';
import { downloadOutput } from '../src/lib/outputDownload';

test('failed HTTP downloads are reported before creating a browser file', async () => {
  await assert.rejects(downloadOutput('/api/download','工作区','result.zip',async () => new Response('missing',{status:404})),/404/);
});
test('empty success responses are never presented as successful files', async () => {
  await assert.rejects(downloadOutput('/api/download','scope','result.zip',async () => new Response(null,{status:204})),/空响应（204）.*逐个下载/);
});

test('empty download responses do not cause automatic retry or resubmission', async () => {
  let calls=0;
  await assert.rejects(downloadOutput('/api/download','scope','result.zip',async () => {
    calls++; return new Response(null,{status:204});
  }),/原文件仍保留/);
  assert.equal(calls,1);
});

test('zero-byte 200 is described as a failed transfer, not proof of an empty source file', async () => {
  await assert.rejects(downloadOutput('/api/download','scope','result.zip',async () => new Response('')),
    /下载响应中的文件为空.*原文件仍保留/);
});
